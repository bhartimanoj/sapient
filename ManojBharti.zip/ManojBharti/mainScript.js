        function displayResult() {
            var denominationsArr = {};
            var denominationsCount = 0;
            let numberInput = document.getElementById("numberInput").value;
            if (numberInput <= 0 || numberInput == "" || numberInput == undefined) {
                alert("Please enter a valid amount");
                document.getElementById("moneyBox").innerHTML = "";
            } else {
                let ListDenominations = [2000, 500, 200, 100, 50, 20, 10, 5, 2, 1];

                for (let i = 0; i < ListDenominations.length; i++) {
                    let MachineNote = ListDenominations[i];
                    let money = Math.floor(numberInput / ListDenominations[i]);
                    denominationsArr[MachineNote] = money;
                    denominationsCount = denominationsCount + money;
                    numberInput = numberInput - (ListDenominations[i] * denominationsArr[MachineNote]);
                }
                document.getElementById("moneyBox").innerHTML = `
                <h3>You will get the following amount</h3>
                <ul class="resultlist">
                <li>
                  <span> ${denominationsArr["1"]} notes of Rs. 1 </span> <span> ${denominationsArr["2"]} notes of Rs. 2 </span>
                </li>
                <li>
                  <span> ${denominationsArr["5"]} notes of Rs. 5 </span> <span> ${denominationsArr["10"]} notes of Rs. 10 </span>
                </li>
                <li>
                  <span> ${denominationsArr["20"]} notes of Rs. 20 </span> <span> ${denominationsArr["50"]} notes of Rs. 50</span>
                </li>
                <li>
                  <span > ${denominationsArr["100"]} notes of Rs. 100 </span> <span> ${denominationsArr["200"]} notes of Rs. 200</span>
                </li>
                <li>
                  <span> ${denominationsArr["500"]} notes of Rs. 500 </span> <span> ${denominationsArr["2000"]} notes of Rs. 2000</span>
                </li>
                </ul>
                 
                  <h3>Total notes dispensed: ${denominationsCount}</h3>
                 <hr/>
                `            }
        }
    